# hackinsta
a program to hack instagram
Yokoback_(instahack) is the file to open, you need libraries write on import. You run that file in the same folder with pass and proxy. and you follow what it say. If you need something on the program i wrote the ways to contact me. I relase upgrade in the time, now it just have 10.787 password.
After download libraries: Json, requestes, random, time, os, sys
You have to open Yokoback_(instahack) then run it file and write the name of account to hack press enter, write n press enter, write 0 press enter.
Then you wait and the program should give you the correct password
If it doesn't work tell me.
I let to you my telegram.
Bye
